using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using OrdersLibrary;

namespace OrdersWindow
{
	public class frmOrders : System.Windows.Forms.Form
	{
		Orders ord;
		SortedList sl = new SortedList();
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.RadioButton rbPlastic;
		private System.Windows.Forms.RadioButton rbWooden;
		private System.Windows.Forms.TextBox txtOrdno;
		private System.Windows.Forms.TextBox txtOrddate;
		private System.Windows.Forms.TextBox txtRate;
		private System.Windows.Forms.TextBox txtOrdvalue;
		private System.Windows.Forms.ComboBox cbColor;
		private System.Windows.Forms.ListBox lstWoodtype;
		private System.Windows.Forms.Button btnPlaceorder;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtQty;
		private System.Windows.Forms.TextBox txtDisplayorder;
		private System.Windows.Forms.Button btnDispall;
		private System.Windows.Forms.Button btnCreate;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmOrders()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.btnCreate = new System.Windows.Forms.Button();
			this.rbWooden = new System.Windows.Forms.RadioButton();
			this.rbPlastic = new System.Windows.Forms.RadioButton();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtOrdno = new System.Windows.Forms.TextBox();
			this.txtOrddate = new System.Windows.Forms.TextBox();
			this.txtRate = new System.Windows.Forms.TextBox();
			this.txtOrdvalue = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.cbColor = new System.Windows.Forms.ComboBox();
			this.lstWoodtype = new System.Windows.Forms.ListBox();
			this.btnPlaceorder = new System.Windows.Forms.Button();
			this.btnDispall = new System.Windows.Forms.Button();
			this.txtQty = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.txtDisplayorder = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.btnCreate);
			this.groupBox1.Controls.Add(this.rbWooden);
			this.groupBox1.Controls.Add(this.rbPlastic);
			this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(24, 56);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(144, 128);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Type";
			// 
			// btnCreate
			// 
			this.btnCreate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCreate.Location = new System.Drawing.Point(32, 96);
			this.btnCreate.Name = "btnCreate";
			this.btnCreate.TabIndex = 2;
			this.btnCreate.Text = "Create";
			this.btnCreate.Click += new System.EventHandler(this.button3_Click);
			// 
			// rbWooden
			// 
			this.rbWooden.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbWooden.Location = new System.Drawing.Point(16, 64);
			this.rbWooden.Name = "rbWooden";
			this.rbWooden.TabIndex = 1;
			this.rbWooden.Text = "Wooden";
			this.rbWooden.CheckedChanged += new System.EventHandler(this.rbWooden_CheckedChanged);
			// 
			// rbPlastic
			// 
			this.rbPlastic.Checked = true;
			this.rbPlastic.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbPlastic.Location = new System.Drawing.Point(16, 24);
			this.rbPlastic.Name = "rbPlastic";
			this.rbPlastic.TabIndex = 0;
			this.rbPlastic.TabStop = true;
			this.rbPlastic.Text = "Plastic";
			this.rbPlastic.CheckedChanged += new System.EventHandler(this.rbPlastic_CheckedChanged);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Blue;
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(504, 32);
			this.label1.TabIndex = 1;
			this.label1.Text = "Order Details";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(240, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(104, 24);
			this.label2.TabIndex = 2;
			this.label2.Text = "Order No.";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(240, 88);
			this.label3.Name = "label3";
			this.label3.TabIndex = 3;
			this.label3.Text = "Order Date";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(240, 128);
			this.label4.Name = "label4";
			this.label4.TabIndex = 4;
			this.label4.Text = "Rate";
			// 
			// txtOrdno
			// 
			this.txtOrdno.Location = new System.Drawing.Point(368, 48);
			this.txtOrdno.Name = "txtOrdno";
			this.txtOrdno.TabIndex = 5;
			this.txtOrdno.Text = "";
			// 
			// txtOrddate
			// 
			this.txtOrddate.Location = new System.Drawing.Point(368, 88);
			this.txtOrddate.Name = "txtOrddate";
			this.txtOrddate.TabIndex = 6;
			this.txtOrddate.Text = "";
			// 
			// txtRate
			// 
			this.txtRate.Location = new System.Drawing.Point(368, 128);
			this.txtRate.Name = "txtRate";
			this.txtRate.TabIndex = 7;
			this.txtRate.Text = "0";
			// 
			// txtOrdvalue
			// 
			this.txtOrdvalue.Enabled = false;
			this.txtOrdvalue.Location = new System.Drawing.Point(368, 208);
			this.txtOrdvalue.Name = "txtOrdvalue";
			this.txtOrdvalue.TabIndex = 8;
			this.txtOrdvalue.Text = "";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(240, 208);
			this.label5.Name = "label5";
			this.label5.TabIndex = 9;
			this.label5.Text = "Order Value";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(240, 248);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(104, 24);
			this.label6.TabIndex = 11;
			this.label6.Text = "Wood Type";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(24, 224);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(80, 23);
			this.label7.TabIndex = 13;
			this.label7.Text = "Color";
			// 
			// cbColor
			// 
			this.cbColor.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cbColor.Items.AddRange(new object[] {
														 "Red",
														 "Blue",
														 "Green"});
			this.cbColor.Location = new System.Drawing.Point(128, 224);
			this.cbColor.Name = "cbColor";
			this.cbColor.Size = new System.Drawing.Size(80, 25);
			this.cbColor.TabIndex = 14;
			this.cbColor.Text = "Red";
			// 
			// lstWoodtype
			// 
			this.lstWoodtype.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lstWoodtype.ItemHeight = 17;
			this.lstWoodtype.Items.AddRange(new object[] {
															 "Oak",
															 "Teak"});
			this.lstWoodtype.Location = new System.Drawing.Point(368, 248);
			this.lstWoodtype.Name = "lstWoodtype";
			this.lstWoodtype.Size = new System.Drawing.Size(96, 38);
			this.lstWoodtype.TabIndex = 15;
			// 
			// btnPlaceorder
			// 
			this.btnPlaceorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPlaceorder.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnPlaceorder.Location = new System.Drawing.Point(304, 304);
			this.btnPlaceorder.Name = "btnPlaceorder";
			this.btnPlaceorder.Size = new System.Drawing.Size(112, 24);
			this.btnPlaceorder.TabIndex = 16;
			this.btnPlaceorder.Text = "Place Order";
			this.btnPlaceorder.Click += new System.EventHandler(this.btnPlaceorder_Click_1);
			// 
			// btnDispall
			// 
			this.btnDispall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnDispall.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnDispall.Location = new System.Drawing.Point(32, 304);
			this.btnDispall.Name = "btnDispall";
			this.btnDispall.Size = new System.Drawing.Size(96, 24);
			this.btnDispall.TabIndex = 17;
			this.btnDispall.Text = "Disp All";
			this.btnDispall.Click += new System.EventHandler(this.btnDispall_Click);
			// 
			// txtQty
			// 
			this.txtQty.Location = new System.Drawing.Point(368, 168);
			this.txtQty.Name = "txtQty";
			this.txtQty.TabIndex = 19;
			this.txtQty.Text = "0";
			this.txtQty.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(240, 168);
			this.label8.Name = "label8";
			this.label8.TabIndex = 18;
			this.label8.Text = "Qty";
			this.label8.Click += new System.EventHandler(this.label8_Click);
			// 
			// txtDisplayorder
			// 
			this.txtDisplayorder.Location = new System.Drawing.Point(152, 304);
			this.txtDisplayorder.Name = "txtDisplayorder";
			this.txtDisplayorder.Size = new System.Drawing.Size(96, 25);
			this.txtDisplayorder.TabIndex = 20;
			this.txtDisplayorder.Text = "";
			// 
			// frmOrders
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 18);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.ClientSize = new System.Drawing.Size(504, 341);
			this.Controls.Add(this.txtDisplayorder);
			this.Controls.Add(this.txtQty);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.btnDispall);
			this.Controls.Add(this.btnPlaceorder);
			this.Controls.Add(this.lstWoodtype);
			this.Controls.Add(this.cbColor);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtOrdvalue);
			this.Controls.Add(this.txtRate);
			this.Controls.Add(this.txtOrddate);
			this.Controls.Add(this.txtOrdno);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.groupBox1);
			this.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "frmOrders";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmOrders());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		lstWoodtype.SelectedIndex=1;
			//to give default selection to lstWoodtype
		}

		private void btnPlaceorder_Click(object sender, System.EventArgs e)
		{
		
		}

		private void rbPlastic_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rbPlastic.Checked==true)
			{//disable woodtype combobox
				lstWoodtype.Enabled=false;
				cbColor.Enabled=true;
			}

		}

		private void rbWooden_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rbWooden.Checked==true)
			{//disable woodtype combobox
				lstWoodtype.Enabled=true;
				cbColor.Enabled=false;
			}

		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			if (rbPlastic.Checked==true)
			{
				ord=new PlasticChair();
		ord.OrderValueChanged+=new OrdersDelegate(this.ord_OrderValueChanged);
			}
			else
			{
				ord=new WoodenChair();
		ord.OrderValueChanged+=new OrdersDelegate(this.ord_OrderValueChanged);
			}
			txtOrdno.Text=ord.OrderNo.ToString();
			txtOrdno.Enabled=false;
btnCreate.Enabled=false;
		}

		private void btnPlaceorder_Click_1(object sender, System.EventArgs e)
		{
			ord.OrderDate=Convert.ToDateTime(txtOrddate.Text);
			ord.Qty=Convert.ToInt32(txtQty.Text);
			if(rbPlastic.Checked==true)
			{
				ord.PRate=Convert.ToSingle(txtRate.Text);
				ord.Color=cbColor.SelectedItem.ToString();
             }
			else
			{	
				ord.WRate =Convert.ToSingle(txtRate.Text);
				ord.WoodType=lstWoodtype.SelectedItem.ToString();
			}
			txtOrdvalue.Text=Convert.ToString(ord.OrderValue);
			sl.Add(txtOrdno.Text,ord);
            //assign ordervalue computed by our class
btnCreate.Enabled=true;

		}

		private void textBox1_TextChanged(object sender, System.EventArgs e)
		{
				
		}

		private void label8_Click(object sender, System.EventArgs e)
		{
		
		}

		private void btnDispall_Click(object sender, System.EventArgs e)
		{
			Orders temp=(Orders)sl[txtDisplayorder.Text];
			//to search the sorted list and return the value.
			//this is an indexer created implicitly for us

			if(temp==null)
				MessageBox.Show("Invalid Order");
			else
				MessageBox.Show(temp.OrderNo+" " +temp.Qty);
			
		}
		private void ord_OrderValueChanged(int ordNo, double ordValue)
		{
	MessageBox.Show("Order Value For Order No : " +  ordNo +  " is" + ordValue);
		}
	}
}

















