using System;
using System.Windows.Forms;

namespace Math_Delegates
{public delegate int MathsDelegate(int a, int b);
	//has to be created here else it gioves error.
	public class MathLibrary
	{
		public MathLibrary()
		{
		}

		public static  int Add(int i , int j)
		{//only for service so static. if i was storing i and j it would be nonstatic function. we are not storing i and j. Like Console.writeLine etc are all static functions
        //  MessageBox.Show((i+j).ToString());
			return (i+j);
		}
		
		public static int Sub(int i , int j)
		{
		//	          MessageBox.Show((i-j).ToString());
			return (i-j);
		}
		public static  int Mult(int i , int j)

		{//only for service so static. if i was storing i and j it would be nonstatic function. we are not storing i and j. Like Console.writeLine etc are all static functions
			          
		//	MessageBox.Show((i*j).ToString());
			return (i*j);
		}public static  int Div(int i , int j)
		 {//only for service so static. if i was storing i and j it would be nonstatic function. we are not storing i and j. Like Console.writeLine etc are all static functions
			
		// MessageBox.Show((i/j).ToString());
			 return (i/j);
		 }
		
	}
}
