using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Math_Delegates;

namespace Math_Delegates
{

	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnOne;
		private System.Windows.Forms.Button btnTwo;
		private System.Windows.Forms.Button btnthree;
		private System.Windows.Forms.Button btnSub;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnDiv;
		private System.Windows.Forms.Button btnMul;
		private System.Windows.Forms.Button btnEql;
		private System.Windows.Forms.TextBox txtAns;
	
		private System.ComponentModel.Container components = null;
		MathsDelegate Func;
		int m1 , m2;
		public Form1()
		{
			InitializeComponent();
		}
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtAns = new System.Windows.Forms.TextBox();
			this.btnOne = new System.Windows.Forms.Button();
			this.btnTwo = new System.Windows.Forms.Button();
			this.btnthree = new System.Windows.Forms.Button();
			this.btnSub = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnDiv = new System.Windows.Forms.Button();
			this.btnMul = new System.Windows.Forms.Button();
			this.btnEql = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtAns
			// 
			this.txtAns.Location = new System.Drawing.Point(56, 16);
			this.txtAns.Name = "txtAns";
			this.txtAns.Size = new System.Drawing.Size(160, 20);
			this.txtAns.TabIndex = 0;
			this.txtAns.Text = "";
			// 
			// btnOne
			// 
			this.btnOne.Location = new System.Drawing.Point(56, 48);
			this.btnOne.Name = "btnOne";
			this.btnOne.Size = new System.Drawing.Size(32, 23);
			this.btnOne.TabIndex = 1;
			this.btnOne.Text = "1";
			this.btnOne.Click += new System.EventHandler(this.btnOne_Click);
			// 
			// btnTwo
			// 
			this.btnTwo.Location = new System.Drawing.Point(96, 48);
			this.btnTwo.Name = "btnTwo";
			this.btnTwo.Size = new System.Drawing.Size(32, 23);
			this.btnTwo.TabIndex = 2;
			this.btnTwo.Text = "2";
			this.btnTwo.Click += new System.EventHandler(this.btnTwo_Click);
			// 
			// btnthree
			// 
			this.btnthree.Location = new System.Drawing.Point(136, 48);
			this.btnthree.Name = "btnthree";
			this.btnthree.Size = new System.Drawing.Size(32, 23);
			this.btnthree.TabIndex = 3;
			this.btnthree.Text = "3";
			this.btnthree.Click += new System.EventHandler(this.btnthree_Click);
			// 
			// btnSub
			// 
			this.btnSub.Location = new System.Drawing.Point(176, 48);
			this.btnSub.Name = "btnSub";
			this.btnSub.Size = new System.Drawing.Size(32, 23);
			this.btnSub.TabIndex = 4;
			this.btnSub.Text = "-";
			this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(176, 80);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(32, 23);
			this.btnAdd.TabIndex = 5;
			this.btnAdd.Text = "+";
			this.btnAdd.Click += new System.EventHandler(this.button2_Click);
			// 
			// btnDiv
			// 
			this.btnDiv.Location = new System.Drawing.Point(176, 112);
			this.btnDiv.Name = "btnDiv";
			this.btnDiv.Size = new System.Drawing.Size(32, 23);
			this.btnDiv.TabIndex = 6;
			this.btnDiv.Text = "/";
			this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
			// 
			// btnMul
			// 
			this.btnMul.Location = new System.Drawing.Point(176, 144);
			this.btnMul.Name = "btnMul";
			this.btnMul.Size = new System.Drawing.Size(32, 23);
			this.btnMul.TabIndex = 7;
			this.btnMul.Text = "*";
			this.btnMul.Click += new System.EventHandler(this.btnMul_Click);
			// 
			// btnEql
			// 
			this.btnEql.Location = new System.Drawing.Point(48, 176);
			this.btnEql.Name = "btnEql";
			this.btnEql.Size = new System.Drawing.Size(160, 24);
			this.btnEql.TabIndex = 8;
			this.btnEql.Text = "=";
			this.btnEql.Click += new System.EventHandler(this.btnEql_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(240, 261);
			this.Controls.Add(this.btnEql);
			this.Controls.Add(this.btnMul);
			this.Controls.Add(this.btnDiv);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.btnSub);
			this.Controls.Add(this.btnthree);
			this.Controls.Add(this.btnTwo);
			this.Controls.Add(this.btnOne);
			this.Controls.Add(this.txtAns);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			Func+=new MathsDelegate(MathLibrary.Add );

		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void btnOne_Click(object sender, System.EventArgs e)
		{
			txtAns.Text="1";
		}

		private void btnTwo_Click(object sender, System.EventArgs e)
		{
			txtAns.Text="2";
		}

		private void btnthree_Click(object sender, System.EventArgs e)
		{
			txtAns.Text="3";
		}

		private void btnSub_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			Func+=new MathsDelegate(MathLibrary.Sub);

		}

		private void btnDiv_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			Func+=new MathsDelegate(MathLibrary.Div );

		}

		private void btnMul_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			Func+=new MathsDelegate(MathLibrary.Mult );

		}

		private void btnEql_Click(object sender, System.EventArgs e)
		{
			m2=Convert.ToInt32(txtAns.Text);
			//COLLECT VALUE FROM TEXT BOX AND STORE IT IN m2

			txtAns.Text=Func(m1,m2).ToString();
		}
	}
}
