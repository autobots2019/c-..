using System;

namespace OrdersLibrary
{
	public class WoodenChair : OrdersLibrary.Orders
	{
		private float wRate;
		private string woodType;
		public WoodenChair()
		{	
			this.wRate=0;
			
		}
		public WoodenChair(string orderDate,int qty,string woodType,float wRate):base			(orderDate,qty)
			//accept datatime paarmeter as string ans convert to date time
			// or he user will have to convert and pass to constructor
         {
				this.WRate=wRate;
			//once properties are in place avoid using data members
			// as properties will have validations etc. 
			//THIS PROPERTY TAKE CARE OF CALLING  CalOrderValue()
			
				WoodType=woodType;
			//note we are assigning to the property Bhere which is doing the checking 
			// of the wood type rather that writing it here.
			// else if the use calls property to assign woodtype
			// we have to write the check condition in property as well
			//as parameterized constructor
	      }
		public override float WRate
		{
			get
			{
				return wRate;
			}
			set
			{
				wRate=value;
				CalcOrderValue();
			}
		}
		public override string WoodType
		{
			get
			{
				return woodType;
			}
			set
			{
				if(value.ToUpper()=="TEAK" || value.ToUpper()=="OAK")
				{
					woodType=value;
				}
				else
				{
					//avoid giving errors
					woodType="Teak";
				}
			}
		}
		public void CalcOrderValue()
		{
			Ovalue=(wRate*Qty);
		}
		
	}
}
