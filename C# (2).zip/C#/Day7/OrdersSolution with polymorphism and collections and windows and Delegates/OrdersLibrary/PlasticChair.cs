using System;

namespace OrdersLibrary
{
	public class PlasticChair : OrdersLibrary.Orders
	{
		private float pRate;
		private string color;
		public PlasticChair()
		{	
			pRate=0;
			
		}
		public PlasticChair(string orderDate,int qty,string color,float pRate):base(orderDate,qty)
			//accept datatime paarmeter as string ans convert to date time
			// or he user will have to convert and pass to constructor 
		{
				PRate=10.0f;
			    //once properties are in place avoid using data members
			    // as properties will have validations etc. 
			    //THIS PROPERTY TAKE CARE OF CALLING  CalOrderValue()
				
			    Color=color;
			//note we are assigning to the property here which is doing the checking 
			// of the color rather that writing it here.
			// else if the use calls property to assign color
			// we have to write the check condition in property as well
			//as parameterized constructor
		}
		public override float PRate
		{
			get
			{
				return pRate;
			}
			set
			{
			  pRate=value;
			  CalcOrderValue();		
			}

		}
		public override string Color
		{
			get
			{
				return color;
			}
			set
			{
				if(value.ToUpper()=="RED" || value.ToUpper()=="GREEN" || value.ToUpper()=="BLUE" )
				{
					color=value;
				}
				else
				{
					color="Red";
				}
			}
		}
		public void CalcOrderValue()
		{
			Ovalue=(pRate*Qty);
		}
		
	}
}
