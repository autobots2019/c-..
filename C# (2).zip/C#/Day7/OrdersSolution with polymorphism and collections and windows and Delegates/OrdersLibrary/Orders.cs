using System;

namespace OrdersLibrary
{	public delegate void OrdersDelegate(int ordNo , double ordValue);
	public class Orders : IDisposable
	{ 
		public event OrdersDelegate OrderValueChanged;
		
		static int lastOrderNo;
		private int orderNo;
		private DateTime orderDate; //note DateTime is a tye but its not n blue as normal		//keyword as it is a structure (value type ) not a keyword
		//String (S caps ) is a class  not a keyword
		private int qty;
		//as far as possible create datamembers as private
		//not protectd . and give acces to properties. so property can do
		// a check on value being assigned. like color property of plastic chair.
		//use property name to assign in parameterized constructors else
		//u have to write the code twice for checking the value
		//once in consrtuctor and again in property.
		private double orderValue;

		// We want ordervalue to be accessiable for modifications only by child classes
		//and not by the user we can create two properties one for child class as protected
		// and one public readonly property with only get for the user to access
		//instead of this only make orderValue as protected so it is accessible
		//for modification to only the child class and user can only read the property
		static Orders()
		{
			lastOrderNo=1000;
		}
		public Orders()
		{
			orderNo=lastOrderNo++;
			orderDate= DateTime.Now;
			qty=0;
			orderValue=0;
		}
		public Orders(string orderDate,int qty):this()
		{
			
			OrderDate=Convert.ToDateTime(orderDate);
			Qty=qty;
		}	
			
		protected double Ovalue
		{
			get
			{
				return orderValue;
			}
			set
			{
				orderValue=value;
				try
				{

					OrderValueChanged(this.orderNo,value);
				}
				catch
				{

				}
				//raising event passing ordno and ordervalue
			}
		}

		public int OrderNo
		{//only access via constructor
			get
			{
				return orderNo;
			}
        }
		public DateTime OrderDate 
		//either have a property returning back a DateTime or a string.
	    // for DateTime user will have to say obj.OrderDate=DateTime.Now;
		// if string then user says Obj.OrderDate="12/05/2005"
		{
			get
			{
				return orderDate;
			}
			set
			{
				orderDate=value;
			}
		}
		public int Qty
		{
			get
			{
				return qty;
			}
			set
			{
				qty=value;
			}
		}

		public double OrderValue
		//for the user TO ACCESS as user should not be able to change the value
		//only read it.
		{
			get
			{
				return orderValue;
			}
			
		}
		~Orders()
		{
			//Console.WriteLine("Destructor");
		}
		#region IDisposable Members

		public void Dispose()
		{
			Console.WriteLine("Dispose");
			System.GC.SuppressFinalize(this);
		}

		#endregion

		public virtual string Color
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public virtual float PRate
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public virtual float WRate
		{
			get
			{
				return 0;
			}
			set
			{
			}
		}

		public virtual string WoodType
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		
	}
}
