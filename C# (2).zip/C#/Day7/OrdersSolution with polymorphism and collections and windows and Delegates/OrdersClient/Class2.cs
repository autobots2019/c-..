using System;
using OrdersLibrary;
namespace OrdersClient
{

	public class Class2
	{
		Orders[] ords = new Orders[2];
		//int i;
		public Class2()
		{
		
		}

		public void Accept()
		{

			string choice;
			
			for(int i=0;i<ords.Length ;i++)
			{
				Console.WriteLine("Enter Choice(Wooden (w)/ Plastic (p)");
				choice=Console.ReadLine();
			if (choice.ToUpper()=="P")
			{
				ords[i]=new PlasticChair();
			//	PlasticChair pTemp=(PlasticChair)ords[i];
				//  we are just type casting the ord[i] objects as that of PlascticChair //class so that we can access the remaining 10 bytes of PlascticChair class
				//dont need if virtual properties  are created
				Console.WriteLine("Enter Order Date");
				ords[i].OrderDate =Convert.ToDateTime (Console.ReadLine());
				Console.WriteLine("Enter Order Quantity");
				ords[i].Qty =Convert.ToInt32(Console.ReadLine());
				Console.WriteLine("Enter Order Rate");
				ords[i].PRate=Convert.ToSingle (Console.ReadLine());
				Console.WriteLine("Enter the Color");
				ords[i].Color=Console.ReadLine();
			}
			else
			{
				ords[i]=new WoodenChair();
			//	WoodenChair wTemp=(WoodenChair)ords[i];
				//  we are just type casting the ord[i] objects as that of PlascticChair //class so that we can access the remaining 10 bytes of PlascticChair class
				//dont need if virtual properties  are created

				//dont need if virtual properties  are created
				Console.WriteLine("Enter Order Date");
				ords[i].OrderDate =Convert.ToDateTime (Console.ReadLine());
				Console.WriteLine("Enter Order Quantity");
				ords[i].Qty =Convert.ToInt32(Console.ReadLine());
				Console.WriteLine("Enter Order Rate");
			ords[i].WRate=Convert.ToSingle (Console.ReadLine());
				Console.WriteLine("Enter the wood type");
				ords[i].WoodType =Console.ReadLine();
				
			}
			
			
			}
		}
		public void Display()
		{
			for(int j=0;j<ords.Length ;j++)
			{
				if(ords[j] is PlasticChair)
				{
					//PlasticChair ptemp=(PlasticChair)(ords[j]);
					Console.WriteLine("Plastic Chair Order Details");
					Console.WriteLine(ords[j].OrderNo);
					Console.WriteLine("Order Date : "+ ords[j].OrderDate);
					Console.WriteLine("Order Color: "+ ords[j].Color);
					Console.WriteLine("Order quantity : " + ords[j].Qty);
					Console.WriteLine("Order value : " + ords[j].OrderValue);

				}
				else if(ords[j] is WoodenChair)
				{
					WoodenChair wtemp=(WoodenChair)(ords[j]);
					Console.WriteLine("Wooden Chair Order Details");
					Console.WriteLine(wtemp.OrderNo);
					Console.WriteLine("Order Date : "+ ords[j].OrderDate);
					//note:  for OrderDate either accept in string from the user or
					//in DateTime format. 
					Console.WriteLine("Wood Type: "+ ords[j].WoodType);
					Console.WriteLine("Order quantity : " + ords[j].Qty);
					Console.WriteLine("Order value : " + ords[j].OrderValue);

					Console.WriteLine(ords[j].ToString());
			
				}
				ords[j].Dispose();	
			}
		}
		
		static void main(string[] args)
			//disabled orderscollection main running
		{
			Class2 c2 = new Class2();
			c2.Accept();
			c2.Display();
		}
	}
}
