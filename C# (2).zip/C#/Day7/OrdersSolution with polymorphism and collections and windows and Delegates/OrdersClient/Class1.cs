using System;
using OrdersLibrary;
namespace OrdersClient
{
	
	class Class1
	{
		int ordNo,ordQty;
		float ordRate;
		string choice,ordDate,ordColor,wType;
		Orders[] ords = new Orders[1];
		/*public void Accept()
		{
			
			for(int i=0;i<ords.Length ;i++)
			{
				//accept info common to both chairs first here
				Console.WriteLine("Enter Order No");
				ordNo=Convert.ToInt32(Console.ReadLine());
				Console.WriteLine("Enter Choice(Wooden (w)/ Plastic (p)");
				choice=Console.ReadLine();
				Console.WriteLine("Enter Order Rate");
				ordRate=Convert.ToSingle(Console.ReadLine());
				Console.WriteLine("Enter Order Date");
				ordDate=Console.ReadLine();
				Console.WriteLine("Enter Order Quantity");
				ordQty=Convert.ToInt32(Console.ReadLine());

				if (choice.ToUpper()=="W")
				{
					Console.WriteLine("Enter the wood type");
					wType=Console.ReadLine();
					ords[i]=new WoodenChair(ordNo,ordDate,ordQty,wType,ordRate);
				}
				else
				{
					Console.WriteLine("Enter the color");
					ordColor=Console.ReadLine();
					ords[i]=new PlasticChair(ordNo,ordDate,ordQty,ordColor,ordRate);
				}
			}
		}
		public void Display()
		{
			for(int j=0;j<ords.Length ;j++)
			{
				if(ords[j] is PlasticChair)
				{
					PlasticChair ptemp=(PlasticChair)(ords[j]);
					Console.WriteLine("Plastic Chair Order Details");
					Console.WriteLine(ptemp.OrderNo);
					Console.WriteLine("Order Date : "+ ptemp.OrderDate);
					Console.WriteLine("Order Color: "+ ptemp.Color);
					Console.WriteLine("Order quantity : " + ptemp.Qty);
					Console.WriteLine("Order value : " + ptemp.OrderValue);

				}
				else if(ords[j] is WoodenChair)
				{
					WoodenChair wtemp=(WoodenChair)(ords[j]);
					Console.WriteLine("Wooden Chair Order Details");
					Console.WriteLine(wtemp.OrderNo);
					Console.WriteLine("Order Date : "+ wtemp.OrderDate);
					//note:  for OrderDate either accept in string from the user or
					//in DateTime format. 
					Console.WriteLine("Wood Type: "+ wtemp.WoodType);
					Console.WriteLine("Order quantity : " + wtemp.Qty);
					Console.WriteLine("Order value : " + wtemp.OrderValue);

					Console.WriteLine(wtemp.ToString());
			
				}
				ords[j].Dispose();	
			}
			}*/
		
		static void main(string[] args)
			//not running m is small 
		{
			//PlasticChair p = new PlasticChair(101,"12/04/2005",5,"Blue",10.0f) ;
		
			//p.CalcOrderValue();
			//user need not call this function as PRate property is calling
			//CalOrderValue() implicitly. It is public function so user can call it.

			/*p.Color="Red";
			p.OrderDate=DateTime.Now;
			p.OrderNo=102;
			p.Qty=10;*/
			//USER CAN ASSIGN TO PROPERTIES OR PASS VALUES TO CONSTRUCTOR.

			/*	Console.WriteLine("Plastic Chair Order Details");
				Console.WriteLine(p.OrderNo);
				Console.WriteLine("Order Date : "+ p.OrderDate);
				Console.WriteLine("Order Color: "+ p.Color);
				Console.WriteLine("Order quantity : " + p.Qty);
				Console.WriteLine("Order value : " + p.OrderValue);*/
			
			//Console.WriteLine("-----------------------------------");
			

			//WoodenChair w = new WoodenChair(102,"12/04/1005",5,"Oak",20.0f);
            
			//w.CalcOrderValue();
			//user need not call this function as PRate property is calling
			//CalOrderValue() implicitly. It is public function so user can call it.


			/*Console.WriteLine("Wooden Chair Order Details");
			Console.WriteLine(w.OrderNo);
			Console.WriteLine("Order Date : "+ w.OrderDate);
			//note:  for OrderDate either accept in string from the user or
			//in DateTime format. 
			Console.WriteLine("Wood Type: "+ w.WoodType);
			Console.WriteLine("Order quantity : " + w.Qty);
			Console.WriteLine("Order value : " + w.OrderValue);

			Console.WriteLine(w.ToString());*/
			//displays OrdersLibrary.WoodenChair
			// if you want toString() function to be made available for your clas to
			//return a value that you want you can override the display method.
			//we will do later 


			//WE WILL CREATE AN ARRAY TO ACCEPT ORDERS GIVING USER OPTION TO SELECT 
			//WHAT TYPE OF CHAIR HE WANTS
			
			//should I accept the value first or should we create the object first.////for orderno we have said get so we cant create the object first. We have to accept //the values first and then pass to the object		
			
	/*		Class1 c = new Class1();
			c.Accept();
			c.Display();*/
				

		}

	}
}
