using System;
using System.Collections;
using OrdersLibrary;
namespace OrdersClient
{
	
	public class OrdersCollection
	{
		ArrayList al = new ArrayList(2);
		//if you dont specify any size it is 16 by default

		public OrdersCollection()
		{
					
		}
		public void Accept()
		{
			Orders ord;
			string choice,cntinue;
			do
			{
					Console.WriteLine("Please enter your choice P/W");
				choice=Console.ReadLine();
				//object should be created and added to the arraylist
				if(choice.ToUpper()=="P")
				{
					ord=new PlasticChair();
					//	PlasticChair pTemp=(PlasticChair)ords[i];
					//  we are just type casting the ord[i] objects as that of PlascticChair //class so that we can access the remaining 10 bytes of PlascticChair class
					//dont need if virtual properties  are created
					Console.WriteLine("Enter Order Date");
					ord.OrderDate =Convert.ToDateTime (Console.ReadLine());
					Console.WriteLine("Enter Order Quantity");
					ord.Qty =Convert.ToInt32(Console.ReadLine());
					Console.WriteLine("Enter Order Rate");
					ord.PRate=Convert.ToSingle (Console.ReadLine());
					Console.WriteLine("Enter the Color");
					ord.Color=Console.ReadLine();
				}
				else
				{
					ord=new WoodenChair();
					//	WoodenChair wTemp=(WoodenChair)ords[i];
					//  we are just type casting the ord[i] objects as that of PlascticChair //class so that we can access the remaining 10 bytes of PlascticChair class
					//dont need if virtual properties  are created

					//dont need if virtual properties  are created
					Console.WriteLine("Enter Order Date");
					ord.OrderDate =Convert.ToDateTime (Console.ReadLine());
					Console.WriteLine("Enter Order Quantity");
					ord.Qty =Convert.ToInt32(Console.ReadLine());
					Console.WriteLine("Enter Order Rate");
					ord.WRate=Convert.ToSingle (Console.ReadLine());
					Console.WriteLine("Enter the wood type");
					ord.WoodType =Console.ReadLine();
				}
				al.Add(ord);
				Console.WriteLine("Do you want to Continue");
				cntinue=Console.ReadLine();

			}while(cntinue.ToUpper()=="Y");
		}

		public void Display()
		{//initially display only capacity and count
		//if you add more than two itmes to the collection the collection is increaed by 2+2 =4 . so capacity will be 4. 
			Console.WriteLine(al.Capacity);
			Console.WriteLine(al.Count);
			for(int i=0;i<al.Count;i++)
			{
			if(al[i] is PlasticChair)
				//to check which type of object is stored in srraylist
				{
					//PlasticChair ptemp=(PlasticChair)(ords[j]);
					//either typecast and store in temp or 
					Console.WriteLine("Plastic Chair Order Details");
					Console.WriteLine(((PlasticChair)al[i]).OrderNo);
				//we are type casting here as al[i] is actually an indexer and an indexer returns always an object. so we have to yype cast from object type to PlascticChair
					Console.WriteLine("Order Date : "+ ((PlasticChair)al[i]).OrderDate);
					Console.WriteLine("Order Color: "+ ((PlasticChair)al[i]).Color);
					Console.WriteLine("Order quantity : " + ((PlasticChair)al[i]).Qty);
					Console.WriteLine("Order value : " + ((PlasticChair)al[i]).OrderValue);

				}
			else if(al[i] is WoodenChair)
			{
				//WoodenChair wtemp=(WoodenChair)(ords[j]);

				Console.WriteLine("Wooden Chair Order Details");
				Console.WriteLine(((WoodenChair)al[i]).OrderNo);
				//we are type casting here as al[i] is actually an indexer and an indexer returns always an object. so we have to yype cast from object type to PlascticChair

				Console.WriteLine("Order Date : "+( (WoodenChair)al[i]).OrderDate);
				//note:  for OrderDate either accept in string from the user or
				//in DateTime format. 
				Console.WriteLine("Wood Type: "+ ((WoodenChair)al[i]).WoodType);
				Console.WriteLine("Order quantity : " +((WoodenChair)al[i]).Qty);
				Console.WriteLine("Order value : " + ((WoodenChair)al[i]).OrderValue);

				Console.WriteLine(al[i].ToString());
			
			}
			}

		}
		static void Main(string[] args)
		{
			OrdersCollection c2 = new OrdersCollection();
			c2.Accept();
			c2.Display();
		}

	}
}
