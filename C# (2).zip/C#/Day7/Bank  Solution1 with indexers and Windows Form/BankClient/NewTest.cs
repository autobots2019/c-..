using System;
using BankLibrary;  // if u dont use this 
namespace BankClient
{
	public class NewTest : BankLibrary.Account
	{
		public NewTest()
		{
			// say if you dont use using savings as savings is in diff namespace
			//BankLibrary.Savings s = new BankLibrary.Savings();
			 //Savings s = new Savings();
			// access given to protected member of Account
			//this.acNo =10;


			// access given to protected member of Account
			//s.acNo=10; 
			
		}
	}
}
