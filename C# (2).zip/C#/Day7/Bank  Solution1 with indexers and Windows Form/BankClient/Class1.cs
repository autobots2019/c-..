using System;
using BankLibrary;
namespace BankClient
{
	class Client
	{
	/*	static void main(string[] args)
			//not running main small class 2 is startup
		{
	

		
			
			Savings s1 = new Savings(101,"Amit",2000.1f,500);
			
			Console.WriteLine("Savings Balance = " + s1.Balance);
			s1.Deposit(1000);
			s1.Witdhraw (3000);
			Console.WriteLine("Savings Balance = " + s1.Balance);
			Current c1 = new  Current(102,"Rohit",3000.22f,1000);
			Console.WriteLine("Current Balance = " + c1.Balance);
			c1.Deposit(1000);
			c1.Witdhraw(500);
			Console.WriteLine("Current Balance = " + c1.Balance);
		
			//Polymorphism
			Maths m = new Maths();
			Console.WriteLine(m.Add(10,20,30));
			Console.WriteLine(m.Add("hello","World","Mastek"));

            //call to function with params
			//Console.WriteLine("No of args passed are :  " + m.Add(1,2,3,4,5,6));

			//for Add(int[] obj)
			int[] temp={1,2,3,4,5};
			Console.WriteLine("No of args passed are :  " + m.Add(temp));

		
			//calling EvenOdd func having out parametes
			int a,b;
			m.EvenOddAdd(out a , out b , 1,2,3,4,5);
			Console.WriteLine("out param a(even nos) =  " + a + " out param b(odd nos) = " + b);

			

		}*/
	}
}




