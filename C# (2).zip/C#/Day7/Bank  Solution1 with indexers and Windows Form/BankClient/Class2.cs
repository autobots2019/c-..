using System;
using BankLibrary;
namespace BankClient
{
	public class Class2
	{
		Account[] acc = new Account[2];
		public void Accept()
		{
			acc[0]=new Account("hello",1000);
			acc[1]=new Account("hello",1000);
			Console.WriteLine(acc[0].AcNo);
			Console.WriteLine(acc[1].AcNo);

		}
		static void Main(string[] args)
		{
			Class2 c2= new Class2();
			c2.Accept();

	//Current x=new Current("aa",10,10);
		//V V V V V V V V V V V IMP PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
			Account a = new Current();
            ((Current)a).cminBal=10;

		//not allowed error
			//Savings s = new Account();
			

			
			//indexer
			Console.WriteLine("Indexer output");
			Account x = new Current();
			x["name"]="Joel";
			Console.WriteLine(x["name"]);//put break point here to view execution path

			Account y = new Savings("Amit",10,100);
            Console.WriteLine(y["acNo"]+":"+y["name"] +":"+ y["balance"]);			
			
			Account z = new Savings("Vineet",20,200);
			Console.WriteLine(z[0] + ":" +z[1] + ":" + z[2]);			
			
			//to access minbal say Savings s = new Savings("Amit",1000,1200);
			//and add indexer to savings class
			Savings s = new Savings("Vijay",30,300);
			Console.WriteLine(s["name"] +":" +s["acNo"] +":"+ s["balance"]+":"+s["minbal"]);	
		}
 	}
}

