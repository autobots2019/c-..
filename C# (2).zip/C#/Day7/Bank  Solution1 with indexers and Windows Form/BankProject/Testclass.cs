using System;

namespace BankLibrary
{
	public class Testclass
	{
		public Testclass()
		{
		
			Savings s = new Savings();
		//	s.acNo=10;
			
		}
	}
}



