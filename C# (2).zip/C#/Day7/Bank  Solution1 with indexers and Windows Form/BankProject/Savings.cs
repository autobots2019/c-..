using System;

namespace BankLibrary
{
	
	public class Savings : BankLibrary.Account
	{
		float minBal;
		public Savings()
		{
			minBal=0;
		}
		public Savings(string name ,float balance,float minBal):base(name,balance)
         {
			this.minBal=minBal;
 		}
		public float MinBal
		{
			get
			{
				return minBal;
			}
			set
			{
				minBal=value;
			}
		}


		public override void Withdraw(float amount)
		{
			float temp = Balance-amount;
			if(temp>minBal)
			{
				base.Withdraw(amount);
			}
			else
			{
				throw new InSufficientBalanceException();
			}
				
		}
		

		public object this[string val]
		{//indexer for minbal
			get
			{
				if(val.ToUpper()=="MINBAL")
					return minBal;
				else
					//return null;
					return base[val];
				//passing to base class indexer
			}
			set
			{
				if(val.ToUpper()=="MINBAL")
					minBal=Convert.ToSingle (value);
				else
					base[val]=value;
			}
		}
		
		
	}
}

