using System;

namespace BankLibrary
{
	public class Maths
	{
		public Maths()
		{
		}
		public int Add(int a , int b , int c)
		{
				return a+b+c;
		}
		public string Add(string a , string b , string c)
		{
			string temp=a+b+c;
			return temp;
		}
		public int Add(int[] obj)
			//if we give (int[] obj) it expects an array of intgers. it will give array
		{
		/*	if( obj.Length>0 )
				return obj[0];
			else
				return obj.Length;*/
			
			//to total all values in the 
			int total=0; //have to initialize as we are using for calculation else gives error
			int len=obj.Length;
			for(int i=0;i<len;i++)
			{
				total=total+obj[i];
			}
			return total;
         
		}
		public int Add(int z,params int[] obj)
		//to differentiate between Add(int[] obj) 
		// we cannot overload with Add(int[] obj) and Add(params int[] obj) gives error.
		{
			int total=0; //have to initialize as we are using for calculation else gives error
			int len=obj.Length;
			for(int i=0;i<len;i++)
			{
				total=total+obj[i];
			}
			return total;
       
		}
		public int EvenOddAdd(out int e, out int o,params int[] obj)
		//output parameters
		{
			int total=0; 
			int len=obj.Length;
			int even =0, odd=0;
			for(int i=0;i<len;i++)
			{
				if(obj[i]%2==0)
				{	
					even++; //cannot directly say e++ gives error saying value of e
							// not initialized before leaving the function
				}
				else 
				{
					odd++; //CANNOT DIRECTLY SAY o++.
				}
						total=total+obj[i];
                              		
				}
			e=even;
			o=odd;
		return total;

		}
    }
}






