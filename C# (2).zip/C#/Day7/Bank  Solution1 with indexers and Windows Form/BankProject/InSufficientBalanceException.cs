using System;

namespace BankLibrary
{
	
	public class InSufficientBalanceException : Exception
	{
		public InSufficientBalanceException(): base("Balance Insufficient")
		{//passing error message up the hierarchy to ApplicationException and finally Exception
		}
	}
}


