using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using BankLibrary;
namespace WindowsApplication1
{
	
	public class Form1 : System.Windows.Forms.Form
	{
		Account aobj;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtAcno;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.TextBox txtBalance;
		private System.Windows.Forms.TextBox txtMinbal;
		private System.Windows.Forms.TextBox txtCminbal;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton rbSavings;
		private System.Windows.Forms.RadioButton rbCurrent;
		private System.Windows.Forms.Button btnCreateaccount;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.ComboBox cbMode;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtAmount;
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Label label9;
		
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			
			InitializeComponent();

			
		}

		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.txtAcno = new System.Windows.Forms.TextBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.txtBalance = new System.Windows.Forms.TextBox();
			this.txtMinbal = new System.Windows.Forms.TextBox();
			this.txtCminbal = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rbSavings = new System.Windows.Forms.RadioButton();
			this.rbCurrent = new System.Windows.Forms.RadioButton();
			this.btnCreateaccount = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.cbMode = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.txtAmount = new System.Windows.Forms.TextBox();
			this.btnOk = new System.Windows.Forms.Button();
			this.label9 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(208, 216);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(112, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "CMin Bal";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(208, 176);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(112, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "Min Bal";
			this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(208, 136);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(112, 23);
			this.label4.TabIndex = 3;
			this.label4.Text = "Balance";
			this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(208, 56);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 23);
			this.label5.TabIndex = 4;
			this.label5.Text = "Ac No.";
			this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(208, 96);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(112, 23);
			this.label6.TabIndex = 5;
			this.label6.Text = "Name";
			this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// txtAcno
			// 
			this.txtAcno.Enabled = false;
			this.txtAcno.Location = new System.Drawing.Point(336, 56);
			this.txtAcno.Name = "txtAcno";
			this.txtAcno.TabIndex = 6;
			this.txtAcno.Text = "";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(336, 96);
			this.txtName.Name = "txtName";
			this.txtName.TabIndex = 7;
			this.txtName.Text = "";
			// 
			// txtBalance
			// 
			this.txtBalance.Location = new System.Drawing.Point(336, 128);
			this.txtBalance.Name = "txtBalance";
			this.txtBalance.TabIndex = 8;
			this.txtBalance.Text = "";
			// 
			// txtMinbal
			// 
			this.txtMinbal.Location = new System.Drawing.Point(336, 168);
			this.txtMinbal.Name = "txtMinbal";
			this.txtMinbal.TabIndex = 9;
			this.txtMinbal.Text = "";
			// 
			// txtCminbal
			// 
			this.txtCminbal.Location = new System.Drawing.Point(336, 208);
			this.txtCminbal.Name = "txtCminbal";
			this.txtCminbal.TabIndex = 10;
			this.txtCminbal.Text = "";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.rbCurrent);
			this.groupBox1.Controls.Add(this.rbSavings);
			this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(16, 56);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(160, 120);
			this.groupBox1.TabIndex = 12;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Account Type";
			// 
			// rbSavings
			// 
			this.rbSavings.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbSavings.Location = new System.Drawing.Point(24, 24);
			this.rbSavings.Name = "rbSavings";
			this.rbSavings.TabIndex = 0;
			this.rbSavings.Text = "Savings";
			this.rbSavings.CheckedChanged += new System.EventHandler(this.rbSavings_CheckedChanged);
			// 
			// rbCurrent
			// 
			this.rbCurrent.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbCurrent.Location = new System.Drawing.Point(24, 80);
			this.rbCurrent.Name = "rbCurrent";
			this.rbCurrent.TabIndex = 1;
			this.rbCurrent.Text = "Current";
			this.rbCurrent.CheckedChanged += new System.EventHandler(this.rbCurrent_CheckedChanged);
			// 
			// btnCreateaccount
			// 
			this.btnCreateaccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnCreateaccount.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnCreateaccount.Location = new System.Drawing.Point(280, 256);
			this.btnCreateaccount.Name = "btnCreateaccount";
			this.btnCreateaccount.Size = new System.Drawing.Size(104, 23);
			this.btnCreateaccount.TabIndex = 13;
			this.btnCreateaccount.Text = "Create Account";
			this.btnCreateaccount.Click += new System.EventHandler(this.btnCreateaccount_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.btnOk);
			this.groupBox2.Controls.Add(this.txtAmount);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.cbMode);
			this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox2.Location = new System.Drawing.Point(16, 296);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(424, 100);
			this.groupBox2.TabIndex = 14;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Transaction";
			// 
			// cbMode
			// 
			this.cbMode.Items.AddRange(new object[] {
														"Withdraw",
														"Deposit"});
			this.cbMode.Location = new System.Drawing.Point(136, 24);
			this.cbMode.Name = "cbMode";
			this.cbMode.Size = new System.Drawing.Size(104, 23);
			this.cbMode.TabIndex = 0;
			this.cbMode.Text = "Deposit";
			this.cbMode.SelectedIndexChanged += new System.EventHandler(this.cbMode_SelectedIndexChanged);
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(16, 24);
			this.label7.Name = "label7";
			this.label7.TabIndex = 1;
			this.label7.Text = "Mode";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(16, 64);
			this.label8.Name = "label8";
			this.label8.TabIndex = 2;
			this.label8.Text = "Amount";
			// 
			// txtAmount
			// 
			this.txtAmount.Location = new System.Drawing.Point(136, 64);
			this.txtAmount.Name = "txtAmount";
			this.txtAmount.TabIndex = 3;
			this.txtAmount.Text = "";
			// 
			// btnOk
			// 
			this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnOk.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnOk.Location = new System.Drawing.Point(304, 64);
			this.btnOk.Name = "btnOk";
			this.btnOk.TabIndex = 4;
			this.btnOk.Text = "OK";
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.Blue;
			this.label9.Location = new System.Drawing.Point(0, 0);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(456, 32);
			this.label9.TabIndex = 15;
			this.label9.Text = "Account Details";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.ClientSize = new System.Drawing.Size(456, 405);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.btnCreateaccount);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.txtCminbal);
			this.Controls.Add(this.txtMinbal);
			this.Controls.Add(this.txtBalance);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.txtAcno);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form1";
			this.Text = "Bank Application";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void label3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void rbSavings_CheckedChanged(object sender, System.EventArgs e)
		{
			txtMinbal.Enabled=true;
			txtCminbal.Enabled=false;
		
		}

		private void btnCreateaccount_Click(object sender, System.EventArgs e)
		{
			if(rbSavings.Checked)
			{
				aobj=new Savings(txtName.Text,Convert.ToSingle(txtBalance.Text),Convert.ToSingle(txtMinbal.Text));
			}
			else
			{
				aobj=new Current(txtName.Text,Convert.ToSingle(txtBalance.Text),Convert.ToSingle(txtCminbal.Text));
			}
			//assigning automatically generated  accno to the textbox;
			//creating object generates accno as we have put that functionality in out banklibrary
			txtAcno.Text =Convert.ToString(aobj.AcNo);
		}

		private void rbCurrent_CheckedChanged(object sender, System.EventArgs e)
		{
			txtMinbal.Enabled=false;
			txtCminbal.Enabled=true;
		
		}

		private void cbMode_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		
		}

		private void btnOk_Click(object sender, System.EventArgs e)
		{
			try
			{
				if(cbMode.SelectedItem.ToString().ToUpper()=="DEPOSIT")
				{
					aobj.Deposit(Convert.ToInt32(txtAmount.Text));
					return;
				}
				else
				{
					aobj.Withdraw (Convert.ToInt32(txtAmount.Text));
					return;
				}
			}
			catch (InSufficientBalanceException ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				MessageBox.Show("Finally");
			}
			txtBalance.Text=Convert.ToString(aobj.Balance);
		}
	}
}
