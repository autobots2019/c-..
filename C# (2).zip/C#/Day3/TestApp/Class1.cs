using System;

namespace TestApp
{
	class Class1
	{
		static void Main(string[] args)
		{
			Permanent emp1 = new Permanent(100,"Amit",1000,300,20);
			//or
			Permanent emp2 = new Permanent();
			emp2.Accept();

		}
	}
}
