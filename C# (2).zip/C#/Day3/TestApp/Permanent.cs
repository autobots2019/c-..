using System;
namespace TestApp
{
	public class Permanent : TestApp.Employee
	{
		private int _allowance;
		private int _leaves;
		public Permanent()
		{
			this._allowance=0;
			this._leaves=0;
		}
		public Permanent(int empno, string empname,float basic,int allowance,int leaves): base(empno,empname,basic)
		{
			this._allowance=allowance;
			this._leaves=leaves;
		}
		public int Allowance
		{
			get
			{
				return this._allowance;
			}
			set
			{
				this._allowance=value;
			}
		}
		public int Leaves
		{
			get
			{
				return this._leaves;
			}
			set
			{
				this._leaves=value;
			}
		}
		public void Accept()
		{
			base.Accept();
			Console.WriteLine("Accept the allowance");
			this._allowance=Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Accept the Leaves");
			this._leaves=Convert.ToInt32(Console.ReadLine());
		}

	}
}
















