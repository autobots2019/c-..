using System;

namespace Polymorphism
{
	public abstract class Instrument
	{
		public static int count=10;
		int _price;
		static Instrument()
		{
			count++;
			Console.WriteLine("Static");
		}
		public Instrument()
		{
			count++;
			Console.WriteLine("Default");
		}
		public abstract void Play();
		public static void Test()
		{

		}
		public void Tune()
		{
			Console.WriteLine("Just Tuning Instrument");
		}
		
	}
}










