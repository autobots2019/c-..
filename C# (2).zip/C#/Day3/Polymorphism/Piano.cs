using System;
namespace Polymorphism
{
	public class Piano:Instrument
	{
		public Piano()
		{
			
		}
		public override void Play()
		{
			Console.WriteLine("Playing Piano");
		}
	}
}










