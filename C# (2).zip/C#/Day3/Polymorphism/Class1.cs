using System;
using System.Text;
namespace Polymorphism
{
	class Temp
	{
		public int x;
	}
	class Class1
	{
		static void Main(string[] args)
		{
			Object obj1 = new Object();
			obj1=10;
			Object obj2 = obj1;
			obj1=20;
			Console.WriteLine(obj2);
			
			
		}
		
	}
	
}





