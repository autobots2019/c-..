using System;

namespace BankLibrary
{
	/// <summary>
	/// 
	/// </summary>
	public class TestClass
	{
		public TestClass()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
	}
}
