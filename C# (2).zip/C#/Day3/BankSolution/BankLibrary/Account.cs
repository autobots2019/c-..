using System;

namespace BankLibrary
{

	public class Account
	{
		public int _acNo;
		string _name;
		float _bal;
		public Account()
		{
			this._acNo=0;
			this._name=string.Empty;
			this._bal=0;
		}
		public Account(int acNo,string name,float bal)
		{
			this._acNo=acNo;
			this._name=name;
			this._bal=bal;
		}
		public int AcNo
		{
			get
			{
				return this._acNo;
			}
			set
			{
				this._acNo=value;
			}
		}
		public string Name 
		{
			get
			{
				return this._name;
			}
			set
			{
				this._name=value;
			}
		}
		public float Bal
		{
			get
			{
				return this._bal;
			}
			set
			{
				this._bal=value;
			}
		}
		public void Accept()
		{
			Console.WriteLine("Ac No");
			this._acNo=Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Cust Name");
			this._name=Console.ReadLine();
			Console.WriteLine("Acc. Balance");
			this._bal=Convert.ToSingle(Console.ReadLine());
		}
		public void Display()
		{
			Console.WriteLine("Ac No" + this._acNo );
			Console.WriteLine("Ac Name" + this._name);
			Console.WriteLine("Ac Bal" + this._bal);
		}
	}
}
