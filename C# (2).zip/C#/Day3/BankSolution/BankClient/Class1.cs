using System;
using BankLibrary;
using System.Text;
namespace BankClient
{
	class Class1
	{
		static void Main(string[] args)
		{
//			Account[] arr = new Account[2];
//			for(int i=0;i<2;i++)
//			{
//				arr[i]= new Account();
//				arr[i].Accept();
//				arr[i].Display();
//			}
//			int odd=0,even=0;
//			for(int i=0;i<2;i++)
//			{
//				int dummy=((arr[i].AcNo%2==0)?even++:odd++);
//			}
//			Console.WriteLine(even);
//			Console.WriteLine(odd);
//			
//			int a=10;
//			Object y=a;
//			Console.WriteLine(y);
//			a=20;
//			Console.WriteLine(y);
		
			
			
			StringBuilder s1 = new StringBuilder("A String");
			StringBuilder s2=s1;
			Console.WriteLine("s1 is " + s1);
			Console.WriteLine("s2 is " + s2);
			s1.Append("Sample");
			Console.WriteLine("s1 is " + s1);
			Console.WriteLine("s2 is " + s2);
			
			
			

						


		}
	}
}











