using System;

namespace BankClient
{
	/// <summary>
	/// 
	/// </summary>
	public class NewClass : BankLibrary.Account
	{
		public NewClass()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
	}
}
