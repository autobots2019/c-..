

namespace Test
{
	class TestClass
	{
		static void Main(string[] args)
		{
		System.Console.WriteLine("Pretty Cool!");	
		} 
		
	}

}
