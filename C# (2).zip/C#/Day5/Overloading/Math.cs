using System;

namespace Overloading
{
	
	public class Math
	{
		public Math()
		{
			
		}
		public string Add(string a, string b)
		{
			return (a+b);
		}
		public string Add(string a, string b,string c)
		{
			return (a+b+c);
		}
//		public int Add(int[] arr)
//		{
//			return arr.Length;
//		}
		public int Add(params Object[] arr)
		{
			return arr.Length;
		}
		public int Process(out int e, out int o,params int[] obj)
		{
			int total=0,even=0,odd=0;
			for(int i=0;i<obj.Length;i++)
			{
				if(obj[i]%2==0)
				{
					even++;
				}
				else
				{
					odd++;			
				}
				total+=obj[i];
			}
			e=even;
			o=odd;
			return total;
		}

	}
}














