using System;

namespace Overloading
{

	class Class1
	{
	
		static void Main(string[] args)
		{
			Math obj = new Math();
			int[] temp={1,2,3,4,5};
			Console.WriteLine(obj.Add(temp));
			Console.WriteLine(obj.Add());
			int a,b;
			Console.WriteLine(obj.Process(out a, out b,1,2,3,4,5,6));
			Console.WriteLine(a);
			Console.WriteLine(b);
		}
	}
}












