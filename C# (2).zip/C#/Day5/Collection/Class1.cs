using System;
using System.Collections;
namespace Collection
{
	class Class1
	{
		static void Main(string[] args)
		{
			Hashtable  srr = new Hashtable();
			srr.Add(1,30);
			srr.Add(2,"hello");
			srr.Add(3,"world");
			
			


		}
	}
}











