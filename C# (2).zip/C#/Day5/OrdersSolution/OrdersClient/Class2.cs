using System;
using OrdersLibrary;
namespace OrdersClient
{
	class Class2
	{
		string choice;
		Orders[] ord = new Orders[2];
		static void main(string[] args)
		{
			Class2 obj = new Class2();
			obj.Accept();
			obj.Display();
		}
		public void Accept()
		{
			for(int i=0;i<2;i++)
			{
				Console.WriteLine("Enter your choice Wooden(W) / Plastic(P)");
				choice=Console.ReadLine();
				if(choice.ToUpper()=="W")
				{
					ord[i]= new WoodenChair();
					Console.WriteLine("Enter the wood type");
					((WoodenChair)ord[i]).WoodType=Console.ReadLine();
				}
				else
				{
					ord[i]= new PlasticChair();
					Console.WriteLine("Enter the color");
					((PlasticChair)ord[i]).Color=Console.ReadLine();
				}
				Console.WriteLine("Enter the order date");
				ord[i].OrderDate=Convert.ToDateTime(Console.ReadLine());
				Console.WriteLine("Enter the order qty");
				ord[i].Qty=Convert.ToInt32(Console.ReadLine());
			}
		}
		public void Display()
		{
			for(int i=0;i<2;i++)
			{
				if(ord[i] is PlasticChair)
				{
					Console.WriteLine("Printing Plastic Order Details");
					Console.WriteLine("****************************");
					Console.WriteLine(ord[i].OrderNo);
					Console.WriteLine(ord[i].OrderDate);
					Console.WriteLine(((PlasticChair)ord[i]).PRate);
					Console.WriteLine(((PlasticChair)ord[i]).Color);
					Console.WriteLine(ord[i].Qty);
					//ord[i].CalculateOrderValue();
					Console.WriteLine(ord[i].OrderValue );
				}
				else if(ord[i] is WoodenChair)
				{
					Console.WriteLine("Printing Wooden Order Details");
					Console.WriteLine("****************************");
					Console.WriteLine(ord[i].OrderNo);
					Console.WriteLine(ord[i].OrderDate);
					Console.WriteLine(ord[i].Qty);
					Console.WriteLine(((WoodenChair)ord[i]).WRate);
					Console.WriteLine(((WoodenChair)ord[i]).WoodType);
					//ord[i].CalculateOrderValue();
					Console.WriteLine(ord[i].OrderValue );

				}
			}
		}
	}
}
