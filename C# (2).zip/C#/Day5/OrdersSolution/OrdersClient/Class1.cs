using System;
using OrdersLibrary;
namespace OrdersClient
{
	class Class1
	{
		int ordQty;
		string choice,ordDate,ordColor,ordWType;
		Orders[] ord = new Orders[2];
		static void Main(string[] args)
		{
			
			Class1 obj = new Class1();
			obj.Accept();
			obj.Display();
		}
		#region This_is_for_accepting
		public void Accept()
		{
		
			for(int i=0;i<ord.Length;i++)
			{
				Console.WriteLine("Enter the order date");
				ordDate=Console.ReadLine();
				Console.WriteLine("Enter the order qty");
				ordQty=Convert.ToInt32(Console.ReadLine());
				Console.WriteLine("Enter your choice Wooden(W) / Plastic(P)");
				choice=Console.ReadLine();
				if(choice.ToUpper()=="W")
				{
					Console.WriteLine("Enter the wood type");
					ordWType=Console.ReadLine();
					ord[i]= new WoodenChair(ordDate,ordQty,ordWType);
				
				
					
				}
				else
				{
					Console.WriteLine("Enter the color");
					ordColor=Console.ReadLine();
					ord[i]= new PlasticChair(ordDate,ordQty,ordColor);
				}

			}
		}
		#endregion
		public void Display()
		{
			for(int i=0;i<2;i++)
			{
				if(ord[i] is PlasticChair)
				{
					Console.WriteLine("Printing Plastic Order Details");
					Console.WriteLine("****************************");
					Console.WriteLine(ord[i][0]);
					Console.WriteLine(ord[i][1]);
					Console.WriteLine(((PlasticChair)ord[i]).PRate);
					Console.WriteLine(((PlasticChair)ord[i]).Color);
					Console.WriteLine(ord[i].Qty);
					//ord[i].CalculateOrderValue();
					Console.WriteLine(ord[i].OrderValue );
				}
				else if(ord[i] is WoodenChair)
				{
					Console.WriteLine("Printing Wooden Order Details");
					Console.WriteLine("****************************");
					Console.WriteLine(ord[i].OrderNo);
					Console.WriteLine(ord[i].OrderDate);
					Console.WriteLine(ord[i].Qty);
					Console.WriteLine(((WoodenChair)ord[i]).WRate);
					Console.WriteLine(((WoodenChair)ord[i]).WoodType);
					//ord[i].CalculateOrderValue();
					Console.WriteLine(ord[i].OrderValue );

				}
				ord[i].Dispose();
			}
		}
	}
}














