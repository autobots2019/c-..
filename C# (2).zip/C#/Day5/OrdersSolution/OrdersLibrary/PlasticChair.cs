using System;

namespace OrdersLibrary
{
	public class PlasticChair : OrdersLibrary.Orders
	{
		private float _pRate;
		private string _color;
    	public PlasticChair()
		{
			this._pRate=10.0f;
			this.Color="Red";
		}
		public PlasticChair(string orderDate, int qty, string color):base(orderDate,qty)
    	{
			this._pRate =10.0f;
			this.CalculateOrderValue();
			this.Color=color;
		}
		public float PRate
		{
			get
			{
				return this._pRate;
			}
		}
		public override object this[int temp]
		{
			get
			{
				if(temp==4)
				{
					return this.Color;
				}
				return base[temp];
			}
			set
			{
				if(temp==4)
				{
					this.Color=Convert.ToString(value);
				}
				else
				{
					base[temp]=value;
				}
			}
		}
		public string Color
		{
			get
			{
				return this._color;
			}
			set
			{
				if(value.ToUpper()=="RED" || value.ToUpper()=="GREEN" || value.ToUpper()=="BLUE")
				{
					this._color=value;
				}
				else 
				{
					this._color="Red";
				}
			}
		}
		public override void CalculateOrderValue()
		{
			this.ch_OrderValue =(this._pRate*Qty);
		}
	}
}
