using System;
using OrdersLibrary;
namespace OrdersClient
{
	class Class1
	{
		static void Main(string[] args)
		{
			PlasticChair p = new PlasticChair();
			Console.WriteLine("Enter the orderno");
			p.OrderNo=Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Enter the order date");
			p.OrderDate=Convert.ToDateTime(Console.ReadLine());
			Console.WriteLine("Enter the order qty");
			p.Qty=Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Enter the color");
			p.Color=Console.ReadLine();
			Console.WriteLine("Printing Plastic Order Details");
			Console.WriteLine("----------------------------");
			//p.CalculateOrderValue();
			Console.WriteLine(p.OrderNo);
			Console.WriteLine(p.OrderDate);
			Console.WriteLine(p.PRate);
			Console.WriteLine(p.Qty);
			Console.WriteLine(p.Color);
			Console.WriteLine(p.OrderValue );
			Console.WriteLine(p.OrderDate.GetType().BaseType.Name);

			Console.WriteLine("****************************");
			WoodenChair w = new WoodenChair(101,"12/4/1006",5,"Blue");
			Console.WriteLine("Printing Wooden Order Details");
			Console.WriteLine("----------------------------");
			w.CalculateOrderValue();
			Console.WriteLine(w.OrderNo);
			Console.WriteLine(w.OrderDate);
			Console.WriteLine(w.WRate);
			Console.WriteLine(w.Qty);
			Console.WriteLine(w.WoodType);
			Console.WriteLine(w.OrderValue );
		}
	}
}
