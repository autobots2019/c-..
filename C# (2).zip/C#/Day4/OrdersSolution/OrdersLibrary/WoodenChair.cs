using System;

namespace OrdersLibrary
{
	public class WoodenChair : OrdersLibrary.Orders
	{
		
		private float _wRate;
		private string _woodType;
		public WoodenChair()
		{
		    this._wRate=20.0f;
			this._woodType="Teak";
		}
		public WoodenChair(int orderno,string orderDate, int qty, string woodType):base(orderno,orderDate,qty)
		{
			
			this._wRate=20.0f;
			this._woodType=woodType;
		}
		public float WRate
		{
			get
			{
				return this._wRate;
			}
		}
		public string WoodType
		{
			get
			{
				return this._woodType;
			}
			set
			{
				if(value.ToUpper()=="TEAK" || value.ToUpper()=="OAK")
				{
					this._woodType=value;
			
				}
				else
				{
					this._woodType="Teak";
				}
			}
		}
		public  void CalculateOrderValue()
		{
			this._orderValue=(this._wRate*Qty);
		}
	}
}
