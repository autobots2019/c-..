using System;

namespace OrdersLibrary
{
	public class PlasticChair : OrdersLibrary.Orders
	{
		private float _pRate;
		private string _color;
    	public PlasticChair()
		{
			this._pRate=10.0f;
			this._color="Red";
		}
		public PlasticChair(int orderno,string orderDate, int qty, string color):base(orderno,orderDate,qty)
    	{
			this._pRate=10.0f;
			
			this._color=color;
		}
		public float PRate
		{
			get
			{
				return this._pRate;
			}
		}
		public string Color
		{
			get
			{
				return this._color;
			}
			set
			{
				if(value.ToUpper()=="RED" || value.ToUpper()=="GREEN" || value.ToUpper()=="BLUE")
				{
					this._color=value;
				}
				else
				{
					this._color="Red";
				}
			}
		}
		public void  CalculateOrderValue()
		{
			this._orderValue=(this._pRate*Qty);
		}
	}
}
