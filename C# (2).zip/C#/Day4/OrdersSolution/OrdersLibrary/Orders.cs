using System;

namespace OrdersLibrary
{
	public class Orders
	{
		private int _orderNo;
		private DateTime _orderDate;
		private int _qty;
		protected double _orderValue;
		public Orders()
		{
			this._orderNo=0;
			this._orderDate=DateTime.Now;
			this._qty=0;
			this._orderValue=0;
		}
		public Orders(int orderNo,string orderDate,int qty)
		{
			this._orderNo=orderNo;
			this._orderDate=Convert.ToDateTime(orderDate);
			this._qty=qty;
		}
		public int OrderNo
		{
			get
			{
				return this._orderNo;
			}
			set
			{
				this._orderNo=value;
			}
		}
		public DateTime OrderDate
		{
			get
			{
				return this._orderDate;
			}
			set
			{
				this._orderDate=value;
			}
		}
		public int Qty
		{
			get
			{
				return this._qty ;
			}
			set
			{

				this._qty=value;

			}
		}
		public double OrderValue
		{
			get
			{
				return this._orderValue;
			}
		}
	

	}
}












