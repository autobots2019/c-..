using System;

namespace OrdersLibrary
{
	abstract public class Orders:IDisposable		
	{
		static int count;
		static Orders()
		{
			count=1000;
		}
		private int _orderNo;
		private DateTime _orderDate;
		private int _qty;
		private double _orderValue;
		public Orders()
		{
			this.OrderNo=count++;
			this.OrderDate=DateTime.Now;
			this.Qty=0;
			this.chOrderValue=0;
		}
		public Orders(string orderDate,int qty):this()
		{
			this.OrderDate=Convert.ToDateTime(orderDate);
			this.Qty=qty;
		}
		public int OrderNo
		{
			get
			{
				return this._orderNo;
			}
			set
			{
				this._orderNo=value;
			}
		}
		public DateTime OrderDate
		{
			get
			{
				return this._orderDate;
			}
			set
			{
				this._orderDate=value;
			}
		}
		public int Qty
		{
			get
			{
				return this._qty ;
			}
			set
			{
				this._qty=value;
				CalculateOrderValue();
			}
		}
		protected double chOrderValue
		{
			get
			{
				return this._orderValue;
			}
			set
			{
				this._orderValue=Math.Abs(value);
			}
		}
		public double OrderValue
		{
			get
			{
				return this._orderValue;
			}
		}
		public abstract void CalculateOrderValue();

		public virtual string Woodtype
		{
			get
			{
				return null;
			}
			set
			{
			}
		}
		~Orders()
		{
			Console.WriteLine("Destructor");
		}
		#region IDisposable Members

		public void Dispose()
		{
			Console.WriteLine("Dispose");
			System.GC.SuppressFinalize(this);
		}

		#endregion
	}
}












