using System;

namespace Types
{
	struct Temp
	{
		int a;
	}
	class Class1
	{
		static void Main(string[] args)
		{
			int x=null;
			

			int a=0;
			Console.WriteLine(a.GetType().BaseType.Name);
	
			string text="";
			Console.WriteLine(text.GetType().BaseType.Name);
			
			Temp obj = new Temp();
			Console.WriteLine(obj.GetType().BaseType.Name);

		}
	}
}















