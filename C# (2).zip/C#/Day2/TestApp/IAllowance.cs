using System;

namespace TestApp
{
	public interface IAllowance
	{	
		 void Cal_PF();
		 void Cal_HRA();
	}
	
}













