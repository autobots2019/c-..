using System;

namespace TestApp
{
	class Class1
	{
		static void Main(string[] args)
		{
			Employee e1= new Employee(11,"Sumit",100); 
			IAllowance obj;
			obj=e1;
			
		}
	}
}

