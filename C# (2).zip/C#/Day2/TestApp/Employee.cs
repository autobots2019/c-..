using System;

namespace TestApp
{
	public class Employee:IAllowance
	{
		int _empNo;
        string _empName;
		float _basic;
		public Employee()
		{
				_empNo=0;
				_basic=0;
				_empName="";
		}
		public Employee(int empNo,string name,float basic)
		{
			this._empNo=empNo;
			this._basic=basic;
			this._empName=name;
		}
		public int EmpNo
		{
			set
			{
				Console.WriteLine("Set called");
				this._empNo=value;
			}
			get
			{
				Console.WriteLine("Get called");
				return this._empNo;
			}

		}
		public float Basic
		{
			set
			{
				this._basic=Math.Abs(value);
			}
			get
			{
				return this._basic;
			}
		}
		public string EmpName
		{
			set
			{
				this._empName=value;
			}
			get
			{
				return this._empName;
			}
		}
		public void Accept()
		{
			Console.WriteLine("Enter the Emp No");
			this._empNo =Convert.ToInt32(Console.ReadLine());
			Console.WriteLine("Enter the Emp Name");
			this._empName=Console.ReadLine();
			Console.WriteLine("Enter the Basic");
			this._basic=Convert.ToSingle(Console.ReadLine());
		}
		public void Display()
		{
			Console.WriteLine("Emp No" + _empNo);
			Console.WriteLine("Emp Name" + _empName);
			Console.WriteLine("Basic" + _basic);
		}
		public static Employee operator++(Employee e1)
		{
			Employee t = (Employee)e1.MemberwiseClone();
			t.Basic+=100;
			return t;
		}
		public  static explicit operator float(Employee e1)
		{
			return e1.Basic;
		}
		public  static explicit operator string(Employee e1)
		{
			return e1.EmpName;
		}
		public static implicit operator Employee(string s)
		{
			Employee e1 = new Employee();
			e1.EmpName=s;
			return e1;
		}
		public static implicit operator Employee(float s)
		{
			Employee e1 = new Employee();
			e1.Basic=s;
			return e1;
		}
		public void Cal_PF(){}
		public void Cal_HRA(){}
		
	}
}

























