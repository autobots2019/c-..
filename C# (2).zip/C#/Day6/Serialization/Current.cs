using System;

namespace BankLibrary
{
	[Serializable]
	public class Current : BankLibrary.Account
	{	
		public float cminBal;
		public Current()
		{
			
		}
		public Current(string name ,float balance,float cminBal):base(name,balance)
		{
			this.cminBal=cminBal;
		}
		public float CMinBal
		{
			get
			{
				return cminBal;
			}	
			set
			{
				cminBal=value;
			}
		}
		public override void Withdraw(float amount)
		{
			float temp = chBalance-amount;
			
				if(temp>cminBal)
				{
					base.Withdraw(amount);
				}
				else
				{
				//	throw new InSufficientBalanceException();
				}
			
			
		}
		
	}
}
