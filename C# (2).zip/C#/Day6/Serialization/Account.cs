using System;
namespace BankLibrary
{
	[Serializable]
	public class Account
	{
		static int lastAccNo =1000;
		private int acNo;
		string name;
		float balance;
		static Account()
		{
			lastAccNo=1000;
	
		}
		public Account()
		{
			acNo=lastAccNo++;
			//to auto assign acc nos
			name="";
			balance=0;
		}
		public Account(string name,float balance):this()
		{//calls base class constructor because of :this() so static var is incremented
			// there only
			//acNo=lastAccNo++;
			//to auto assign acc nos
			//better to put this in def caonstructor and just call def constr here
			this.acNo=acNo;
			this.name=name;
			this.balance=balance;		
		}
		public int AcNo 
		{//no set as user cannot set accno
			get
			{
				return acNo;
			}
			
		}
		public string Name
		{
			get
			{
				return name;
			}
			set
			{
				name=value;
			}
		}
		public float Balance //for client / user
		{
			get
			{
				return balance;
			}
		}
		protected float chBalance //for child classes
		{
			get
			{
				return balance;
			}
			set
			{
				balance=value;
			}
		}
		
		public  void Deposit(float amount)
		{
			balance+=amount;
		
		}
		public virtual void Withdraw(float amount)
		{
			balance-=amount; 
		}

		public object this[string val]
		{//indexer
			get
			{
				if(val.ToUpper()=="ACNO")
                    return acNo;//all variable names not propery
				if(val.ToUpper()=="NAME")
					return name;
				//if we say else here before return balance whats the error. 
				//this else is for the preceeding if only and not for the entire if block. it will run the same way but it is not logically correct. if first condition is true it goes inside first "if". then if second "if" is false it goes into else of second "if" and retuns that value.
				//can put one more "if" here as it will give code has no return value error
				return balance;

		//works for obj[name]="jj";
				// if we want support for number based indexer obj[0]="dd"
				//then if(val)==0) 
				//if(val==1)
			}
			set
			{
				if(val.ToUpper()=="NAME")
					name=value.ToString();
				//have to type cast as the value will be in type Object. we have to convert to string. It is received in Object form as we specify when creating indexer



			}
		}

		public object this[int tempval]
		{
			get
			{
				if(tempval==0)
					return acNo;//variable name
				else if(tempval==1)
					return name;
				//if we say else here before return balance whats the error. 
				//this else is for the preceeding if only and not for the entire if block. it will run the same way but it is not logically correct. if first condition is true it goes inside first "if". then if second "if" is false it goes into else of second "if" and retuns that value.
				//can put one more "if" here as it will give code has no return value error
				else
				return balance;
			}
			set
			{
				if(tempval==0)
					acNo=Convert.ToInt32(value);
			}
		}
		
	}
}
