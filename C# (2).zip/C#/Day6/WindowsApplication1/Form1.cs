using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WindowsApplication1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnVal;
		private System.Windows.Forms.TextBox txtValue;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ListBox lstValues;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.CheckBox chkBox1;
		private System.Windows.Forms.CheckBox chkBox2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton4;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnVal = new System.Windows.Forms.Button();
			this.txtValue = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lstValues = new System.Windows.Forms.ListBox();
			this.label2 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.chkBox1 = new System.Windows.Forms.CheckBox();
			this.chkBox2 = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnVal
			// 
			this.btnVal.Location = new System.Drawing.Point(112, 328);
			this.btnVal.Name = "btnVal";
			this.btnVal.TabIndex = 0;
			this.btnVal.Text = "button1";
			this.btnVal.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtValue
			// 
			this.txtValue.Location = new System.Drawing.Point(152, 48);
			this.txtValue.Name = "txtValue";
			this.txtValue.Size = new System.Drawing.Size(120, 23);
			this.txtValue.TabIndex = 1;
			this.txtValue.Text = "";
			this.txtValue.TextChanged += new System.EventHandler(this.txtValue_TextChanged);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(32, 48);
			this.label1.Name = "label1";
			this.label1.TabIndex = 2;
			this.label1.Text = "Enter Value";
			// 
			// lstValues
			// 
			this.lstValues.ItemHeight = 16;
			this.lstValues.Items.AddRange(new object[] {
														   "C#",
														   "ASP.net",
														   "VB.net",
														   "SOA"});
			this.lstValues.Location = new System.Drawing.Point(152, 80);
			this.lstValues.Name = "lstValues";
			this.lstValues.Size = new System.Drawing.Size(120, 84);
			this.lstValues.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(32, 80);
			this.label2.Name = "label2";
			this.label2.TabIndex = 4;
			this.label2.Text = "Options";
			// 
			// comboBox1
			// 
			this.comboBox1.Items.AddRange(new object[] {
														   "Item1",
														   "Item2",
														   "Item#"});
			this.comboBox1.Location = new System.Drawing.Point(152, 184);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(121, 24);
			this.comboBox1.TabIndex = 5;
			this.comboBox1.Text = "comboBox1";
			// 
			// chkBox1
			// 
			this.chkBox1.Location = new System.Drawing.Point(48, 216);
			this.chkBox1.Name = "chkBox1";
			this.chkBox1.TabIndex = 6;
			this.chkBox1.Text = "checkBox1";
			// 
			// chkBox2
			// 
			this.chkBox2.Location = new System.Drawing.Point(152, 216);
			this.chkBox2.Name = "chkBox2";
			this.chkBox2.TabIndex = 7;
			this.chkBox2.Text = "checkBox2";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.radioButton2);
			this.groupBox1.Controls.Add(this.radioButton1);
			this.groupBox1.Location = new System.Drawing.Point(296, 56);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.TabIndex = 8;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "groupBox1";
			// 
			// radioButton1
			// 
			this.radioButton1.Location = new System.Drawing.Point(24, 24);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.TabIndex = 0;
			this.radioButton1.Text = "radioButton1";
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(24, 56);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.TabIndex = 1;
			this.radioButton2.Text = "radioButton2";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.radioButton4);
			this.groupBox2.Controls.Add(this.radioButton3);
			this.groupBox2.Location = new System.Drawing.Point(304, 184);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.TabIndex = 9;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "groupBox2";
			// 
			// radioButton3
			// 
			this.radioButton3.Location = new System.Drawing.Point(16, 24);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.TabIndex = 0;
			this.radioButton3.Text = "radioButton3";
			// 
			// radioButton4
			// 
			this.radioButton4.Location = new System.Drawing.Point(16, 56);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.TabIndex = 1;
			this.radioButton4.Text = "radioButton4";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 16);
			this.ClientSize = new System.Drawing.Size(528, 389);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.chkBox2);
			this.Controls.Add(this.chkBox1);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.lstValues);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtValue);
			this.Controls.Add(this.btnVal);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			btnVal.Enabled=false;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show(chkBox1.Checked.ToString());
		}

		private void txtValue_TextChanged(object sender, System.EventArgs e)
		{
			btnVal.Enabled=true;
		}
	}
}














