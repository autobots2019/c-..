using System;

namespace ErrorHandling
{
	class Class1
	{
		static void Main(string[] args)
		{
			try
			{
				Display();
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
		static void Display()
		{
			try
			{
					int[] x=new int[1];
					x[3]=10;
			}
			finally
			{
			}
		}
	}
}




























