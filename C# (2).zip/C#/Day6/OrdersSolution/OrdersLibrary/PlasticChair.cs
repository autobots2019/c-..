using System;

namespace OrdersLibrary
{
	public class PlasticChair : OrdersLibrary.Orders
	{
		private float _pRate;
		private string _color;
    	public PlasticChair()
		{
			this._pRate=10.0f;
			this.Color="Red";
		}
		public PlasticChair(string orderDate, int qty, string color):base(orderDate,qty)
    	{
			this._pRate =10.0f;
			this.CalculateOrderValue();
			this.Color=color;
		}
		public override float PRate
		{
			get
			{
				return this._pRate;
			}
		}

		public override string Color
		{
			get
			{
				return this._color;
			}
			set
			{
				if(value.ToUpper()=="RED" || value.ToUpper()=="GREEN" || value.ToUpper()=="BLUE")
				{
					this._color=value;
				}
				else
				{
					this._color="Red";
				}
			}
		}
		public override void CalculateOrderValue()
		{
			this.ch_OrderValue =(this._pRate*Qty);
		}

		public override object this[int temp]
		{
			get
			{
				if(temp==3)
				{
					return PRate;
				}
				else
				{
					return base[temp];
				}

			}
			set
			{
				if(temp==3)
				{
					this._pRate=Convert.ToSingle(value);
				}
				else
				{
					base[temp]=value;
				}
			}
		}
	}
}
