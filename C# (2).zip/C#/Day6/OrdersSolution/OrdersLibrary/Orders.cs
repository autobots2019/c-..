using System;

namespace OrdersLibrary
{
	abstract public class Orders
	{
		private static int _scount=1000;
		private int _orderNo;
		private DateTime _orderDate;
		private int _qty;
		private double _orderValue;
		public Orders()
		{
			_orderNo=_scount++;
			this.OrderDate=DateTime.Now;
			this.Qty=0;
			this.ch_OrderValue=0;
		}
		public Orders(string orderDate,int qty):this()
		{
			this.OrderDate=Convert.ToDateTime(orderDate);
			this.Qty=qty;
		}
		public int OrderNo
		{
			get
			{
				return _orderNo;
			}
		}
		public DateTime OrderDate
		{
			get
			{
				return this._orderDate;
			}
			set
			{
				this._orderDate=Convert.ToDateTime(value);
			}
		}
		
		public int Qty
		{
			get
			{
				return this._qty ;
			}
			set
			{
				this._qty=Convert.ToInt32(value);
				this.CalculateOrderValue();
			}
		}
		public double OrderValue
		{
			get
			{
				return this._orderValue;
			}
		}
		protected double ch_OrderValue
		{
			get
			{
				return this._orderValue;
			}
			set
			{
				this._orderValue=Math.Abs(value);
			}
		}
		abstract public void CalculateOrderValue();

		public virtual object this[int temp]
		{
			get
			{
				if(temp==0)
				{
					return this.OrderNo;
				}
				else if(temp==1)
				{
					return this.OrderDate;
				}
				else if(temp==2)
				{
					return this.Qty;
				}
				return null;
			}
			set
			{
				if(temp==0)
				{
					this._orderNo=Convert.ToInt32(value);
				}
				else if(temp==1)
				{
					OrderDate=Convert.ToDateTime(value);
				}
				else if(temp==2)
				{
					Qty=Convert.ToInt32(value);
				}
			}
		}

		public virtual string Color
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		public virtual float WRate
		{
			get
			{
				return 0;
			}
		}

		public virtual float PRate
		{
			get
			{
				return 0;
			}
		}

		public virtual string WoodType
		{
			get
			{
				return null;
			}
			set
			{
			}
		}
	}
}












