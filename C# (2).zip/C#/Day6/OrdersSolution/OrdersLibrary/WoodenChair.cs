using System;

namespace OrdersLibrary
{
	public class WoodenChair : OrdersLibrary.Orders
	{
		private float _wRate;
		private string _woodType;
		public WoodenChair()
		{
			this._wRate=20.0f;
			this.WoodType="Teak";
		}
		public WoodenChair(string orderDate, int qty, string woodType):base(orderDate,qty)
		{
			this._wRate=20.0f;
			this.CalculateOrderValue();
			this.WoodType=woodType;
		}
		public override float WRate
		{
			get
			{
				return this._wRate;
			}
		}
		public override string WoodType
		{
			get
			{
				return this._woodType;
			}
			set
			{
				if(value.ToUpper()=="TEAK" || value.ToUpper()=="OAK")
				{
					this._woodType=value;
				}
				else
				{
					this._woodType="Teak";
				}
			}
		}
		public override object this[int temp]
		{
			get
			{
				if(temp==3)
				{
					return WRate;
				}
				else
				{
					return base[temp];
				}

			}
			set
			{
				if(temp==3)
				{
					this._wRate=Convert.ToSingle(value);
				}
				else
				{
					base[temp]=value;
				}
			}
		}
		public override void CalculateOrderValue()
		{
			this.ch_OrderValue=(this._wRate*Qty);
		}
	}
}
