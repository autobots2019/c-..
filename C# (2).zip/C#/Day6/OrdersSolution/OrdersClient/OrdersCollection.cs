using System;
using OrdersLibrary;
using System.Collections;
namespace OrdersClient
{
	public class OrdersCollection
	{
		ArrayList arr = new ArrayList(2);
		
		static void Main(string[] args)
		{
			OrdersCollection obj = new OrdersCollection();
			obj.Accept();
			obj.Display();
		}
		public void Accept()
		{
			Orders ord;
			string choice, cnt=string.Empty;
			do
			{
        		Console.WriteLine("Please enter your choice P/W");
				choice = Console.ReadLine();
				if(choice.ToUpper()=="P")
				{
					ord= new PlasticChair();
					Console.WriteLine("Enter order date");
					ord.OrderDate=Convert.ToDateTime(Console.ReadLine());
					Console.WriteLine("Enter Qty");
					ord.Qty=Convert.ToInt32(Console.ReadLine());
					Console.WriteLine("Enter Color");
					ord.Color=Console.ReadLine();
				}
				else
				{
					ord= new WoodenChair();
					Console.WriteLine("Enter order date");
					ord.OrderDate=Convert.ToDateTime(Console.ReadLine());
					Console.WriteLine("Enter Qty");
					ord.Qty=Convert.ToInt32(Console.ReadLine());
					Console.WriteLine("Enter Color");
					ord.WoodType=Console.ReadLine();
				}
				arr.Add(ord);
				Console.WriteLine("Continue Y/N");
				cnt = Console.ReadLine();
			}while(cnt.ToUpper()=="Y");

		}
		public void Display()
		{
			
				for(int i=0;i<arr.Count;i++)
				{
					if(arr[i] is PlasticChair)
					{
						Console.WriteLine("Printing Plastic Order Details");
						Console.WriteLine("****************************");
						Console.WriteLine(((PlasticChair)arr[i]).OrderNo);
						Console.WriteLine(((PlasticChair)arr[i]).OrderDate);
						Console.WriteLine(((PlasticChair)arr[i]).PRate);
						Console.WriteLine(((PlasticChair)arr[i]).Color);
						Console.WriteLine(((PlasticChair)arr[i]).Qty);
						Console.WriteLine(((PlasticChair)arr[i]).OrderValue );
					}
					else if(arr[i] is WoodenChair)
					{
						Console.WriteLine("Printing Wooden Order Details");
						Console.WriteLine("****************************");
						Console.WriteLine(((WoodenChair)arr[i]).OrderNo);
						Console.WriteLine(((WoodenChair)arr[i]).OrderDate);
						Console.WriteLine(((WoodenChair)arr[i]).Qty);
						Console.WriteLine(((WoodenChair)arr[i]).WRate);
						Console.WriteLine(((WoodenChair)arr[i]).WoodType);
						Console.WriteLine(((WoodenChair)arr[i]).OrderValue );
					}
				}
			}
		}
	}

