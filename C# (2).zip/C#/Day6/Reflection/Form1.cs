using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using BankLibrary;
using System.Reflection;
namespace Reflection
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		Type[] typeArr;
		MethodInfo[] methArr;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ListBox lstMethods;
		private System.Windows.Forms.Button btnType;
		private System.Windows.Forms.ListBox lstFields;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListBox lstParameters;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label txtAssembly;
		private System.Windows.Forms.TextBox txt;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.ListBox lstClasses;
		private System.Windows.Forms.Label label5;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.lstMethods = new System.Windows.Forms.ListBox();
			this.btnType = new System.Windows.Forms.Button();
			this.lstFields = new System.Windows.Forms.ListBox();
			this.label3 = new System.Windows.Forms.Label();
			this.lstParameters = new System.Windows.Forms.ListBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtAssembly = new System.Windows.Forms.Label();
			this.txt = new System.Windows.Forms.TextBox();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.lstClasses = new System.Windows.Forms.ListBox();
			this.label5 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Blue;
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(576, 40);
			this.label1.TabIndex = 0;
			this.label1.Text = "Reflection";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(200, 144);
			this.label2.Name = "label2";
			this.label2.TabIndex = 1;
			this.label2.Text = "Methods";
			// 
			// lstMethods
			// 
			this.lstMethods.Location = new System.Drawing.Point(208, 184);
			this.lstMethods.Name = "lstMethods";
			this.lstMethods.Size = new System.Drawing.Size(152, 173);
			this.lstMethods.TabIndex = 2;
			this.lstMethods.SelectedIndexChanged += new System.EventHandler(this.lstMethods_SelectedIndexChanged);
			// 
			// btnType
			// 
			this.btnType.Location = new System.Drawing.Point(304, 376);
			this.btnType.Name = "btnType";
			this.btnType.Size = new System.Drawing.Size(152, 23);
			this.btnType.TabIndex = 3;
			this.btnType.Text = "GetType";
			this.btnType.Click += new System.EventHandler(this.btnType_Click);
			// 
			// lstFields
			// 
			this.lstFields.Location = new System.Drawing.Point(384, 184);
			this.lstFields.Name = "lstFields";
			this.lstFields.Size = new System.Drawing.Size(152, 173);
			this.lstFields.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(376, 144);
			this.label3.Name = "label3";
			this.label3.TabIndex = 4;
			this.label3.Text = "Fields";
			// 
			// lstParameters
			// 
			this.lstParameters.Location = new System.Drawing.Point(560, 184);
			this.lstParameters.Name = "lstParameters";
			this.lstParameters.Size = new System.Drawing.Size(152, 173);
			this.lstParameters.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(552, 144);
			this.label4.Name = "label4";
			this.label4.TabIndex = 6;
			this.label4.Text = "Parameters";
			// 
			// txtAssembly
			// 
			this.txtAssembly.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtAssembly.Location = new System.Drawing.Point(24, 72);
			this.txtAssembly.Name = "txtAssembly";
			this.txtAssembly.Size = new System.Drawing.Size(152, 23);
			this.txtAssembly.TabIndex = 8;
			this.txtAssembly.Text = "Assembly";
			// 
			// txt
			// 
			this.txt.Location = new System.Drawing.Point(208, 72);
			this.txt.Name = "txt";
			this.txt.Size = new System.Drawing.Size(328, 20);
			this.txt.TabIndex = 9;
			this.txt.Text = "";
			// 
			// btnBrowse
			// 
			this.btnBrowse.Location = new System.Drawing.Point(568, 72);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(136, 23);
			this.btnBrowse.TabIndex = 10;
			this.btnBrowse.Text = "Browse";
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = "Dynamic Link Library (*.dll)|*.dll| Executable (*.exe)|*.exe";
			// 
			// lstClasses
			// 
			this.lstClasses.Location = new System.Drawing.Point(32, 184);
			this.lstClasses.Name = "lstClasses";
			this.lstClasses.Size = new System.Drawing.Size(152, 173);
			this.lstClasses.TabIndex = 12;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(24, 144);
			this.label5.Name = "label5";
			this.label5.TabIndex = 11;
			this.label5.Text = "Classes";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(752, 421);
			this.Controls.Add(this.lstClasses);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.btnBrowse);
			this.Controls.Add(this.txt);
			this.Controls.Add(this.txtAssembly);
			this.Controls.Add(this.lstParameters);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lstFields);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.btnType);
			this.Controls.Add(this.lstMethods);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "Reflection Application";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnType_Click(object sender, System.EventArgs e)
		{
			Type t= typeof(Account);
			MethodInfo[] methods=t.GetMethods();
			lstMethods.DataSource=methods;
			lstMethods.DisplayMember="Name";
			FieldInfo[] fields=	t.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			lstFields.DataSource=fields;
			lstFields.DisplayMember="Name";
		}

		private void lstMethods_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		MethodInfo minfo=(MethodInfo)lstMethods.SelectedItem;

		ParameterInfo[] pinfo=minfo.GetParameters();
		lstParameters.Items.Clear();
			foreach(ParameterInfo p in pinfo)
			{
				object o=p.ParameterType.Name + "  " +p.Name;
				lstParameters.Items.Add(o);
			}
		}

		private void btnBrowse_Click(object sender, System.EventArgs e)
		{
			openFileDialog1.ShowDialog();
			txtAssembly.Text=openFileDialog1.FileName;

			Assembly a=Assembly.LoadFile(openFileDialog1.FileName);
			typeArr=a.GetTypes();
			lstClasses.DataSource=typeArr;
			lstClasses.DisplayMember="Name";
		}
		private void Form1_Load(object sender, System.EventArgs e)
		{
					
		}
	}
}




















