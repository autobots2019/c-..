using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Delegates
{
	
	public class Form1 : System.Windows.Forms.Form
	{
		MathsDelegate ptrFunc;
		int m1,m2;
		private System.Windows.Forms.Button btnEql;
		private System.Windows.Forms.Button btnMul;
		private System.Windows.Forms.Button btnDiv;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnSub;
		private System.Windows.Forms.Button btnthree;
		private System.Windows.Forms.Button btnTwo;
		private System.Windows.Forms.Button btnOne;
		private System.Windows.Forms.TextBox txtAns;
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnEql = new System.Windows.Forms.Button();
			this.btnMul = new System.Windows.Forms.Button();
			this.btnDiv = new System.Windows.Forms.Button();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnSub = new System.Windows.Forms.Button();
			this.btnthree = new System.Windows.Forms.Button();
			this.btnTwo = new System.Windows.Forms.Button();
			this.btnOne = new System.Windows.Forms.Button();
			this.txtAns = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnEql
			// 
			this.btnEql.Location = new System.Drawing.Point(24, 192);
			this.btnEql.Name = "btnEql";
			this.btnEql.Size = new System.Drawing.Size(160, 24);
			this.btnEql.TabIndex = 17;
			this.btnEql.Text = "=";
			this.btnEql.Click += new System.EventHandler(this.btnEql_Click);
			// 
			// btnMul
			// 
			this.btnMul.Location = new System.Drawing.Point(152, 160);
			this.btnMul.Name = "btnMul";
			this.btnMul.Size = new System.Drawing.Size(32, 23);
			this.btnMul.TabIndex = 16;
			this.btnMul.Text = "*";
			this.btnMul.Click += new System.EventHandler(this.btnMul_Click);
			// 
			// btnDiv
			// 
			this.btnDiv.Location = new System.Drawing.Point(152, 128);
			this.btnDiv.Name = "btnDiv";
			this.btnDiv.Size = new System.Drawing.Size(32, 23);
			this.btnDiv.TabIndex = 15;
			this.btnDiv.Text = "/";
			this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(152, 96);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(32, 23);
			this.btnAdd.TabIndex = 14;
			this.btnAdd.Text = "+";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnSub
			// 
			this.btnSub.Location = new System.Drawing.Point(152, 64);
			this.btnSub.Name = "btnSub";
			this.btnSub.Size = new System.Drawing.Size(32, 23);
			this.btnSub.TabIndex = 13;
			this.btnSub.Text = "-";
			this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
			// 
			// btnthree
			// 
			this.btnthree.Location = new System.Drawing.Point(112, 64);
			this.btnthree.Name = "btnthree";
			this.btnthree.Size = new System.Drawing.Size(32, 23);
			this.btnthree.TabIndex = 12;
			this.btnthree.Text = "3";
			this.btnthree.Click += new System.EventHandler(this.btnthree_Click);
			// 
			// btnTwo
			// 
			this.btnTwo.Location = new System.Drawing.Point(72, 64);
			this.btnTwo.Name = "btnTwo";
			this.btnTwo.Size = new System.Drawing.Size(32, 23);
			this.btnTwo.TabIndex = 11;
			this.btnTwo.Text = "2";
			this.btnTwo.Click += new System.EventHandler(this.btnTwo_Click);
			// 
			// btnOne
			// 
			this.btnOne.Location = new System.Drawing.Point(32, 64);
			this.btnOne.Name = "btnOne";
			this.btnOne.Size = new System.Drawing.Size(32, 23);
			this.btnOne.TabIndex = 10;
			this.btnOne.Text = "1";
			this.btnOne.Click += new System.EventHandler(this.btnOne_Click);
			// 
			// txtAns
			// 
			this.txtAns.Location = new System.Drawing.Point(32, 32);
			this.txtAns.Name = "txtAns";
			this.txtAns.Size = new System.Drawing.Size(160, 20);
			this.txtAns.TabIndex = 9;
			this.txtAns.Text = "";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(40, 128);
			this.button1.Name = "button1";
			this.button1.TabIndex = 18;
			this.button1.Text = "button1";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			this.button1.Click += new System.EventHandler(this.MyClick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(216, 245);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnEql);
			this.Controls.Add(this.btnMul);
			this.Controls.Add(this.btnDiv);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.btnSub);
			this.Controls.Add(this.btnthree);
			this.Controls.Add(this.btnTwo);
			this.Controls.Add(this.btnOne);
			this.Controls.Add(this.txtAns);
			this.Name = "Form1";
			this.Text = "Calc";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}

		private void btnSub_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			ptrFunc+=new MathsDelegate(MathsLibrary.Sub);
		}
		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			ptrFunc+=new MathsDelegate(MathsLibrary.Add);
		}
		private void btnDiv_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			ptrFunc+=new MathsDelegate(MathsLibrary.Div);
		}
		private void btnMul_Click(object sender, System.EventArgs e)
		{
			m1=Convert.ToInt32(txtAns.Text);
			ptrFunc+= new MathsDelegate(MathsLibrary.Mult);
		}
		private void btnOne_Click(object sender, System.EventArgs e)
		{
			txtAns.Text="1";
		}
		private void btnTwo_Click(object sender, System.EventArgs e)
		{
			txtAns.Text="2";
		}
		private void btnthree_Click(object sender, System.EventArgs e)
		{
			txtAns.Text="3";
		}

		private void btnEql_Click(object sender, System.EventArgs e)
		{
			m2=Convert.ToInt32(txtAns.Text);
			txtAns.Text=ptrFunc(m1,m2).ToString();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Default Click");
		}
		private void MyClick(object sender, System.EventArgs e)
		{
			MessageBox.Show("My Click");
		}
	}
}











