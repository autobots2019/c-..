using System;
using System.Windows.Forms;
namespace Delegates
{
	public delegate int MathsDelegate(int a , int b);
	public class MathsLibrary
	{
		public static int Add(int x , int y)
		{
			MessageBox.Show((x+y).ToString());	
			return (x+y);
		}
		public static int Sub(int x , int y)
		{
			MessageBox.Show((x-y).ToString());
			return (x-y);
		}
		public static int Mult(int x , int y)
		{
			MessageBox.Show((x*y).ToString());
			return (x*y);
		}
		public static int Div(int x , int y)
		{
			MessageBox.Show((x/y).ToString());
			return (x/y);
		}
	}
}
